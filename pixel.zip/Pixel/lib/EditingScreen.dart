import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class EditingScreen extends StatefulWidget {
  XFile imageFile;

  EditingScreen({super.key, required this.imageFile});

  @override
  _EditingScreenState createState() => _EditingScreenState();
}

class _EditingScreenState extends State<EditingScreen> {
  int twoButtonTndex = 0;

  void _onItemButtonsTap(int index) {
    setState(() {
      twoButtonTndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: Image.file(File(widget.imageFile.path)).image,
              fit: BoxFit.cover),
        ),
        child: Column(
          children: [
            Container(
              color: Colors.white.withOpacity(0.4),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.close,
                      ),
                      color: Colors.black,
                      onPressed: () {
                        Navigator.pop(context);
                        // do something when the first icon button is pressed
                      },
                    ),
                    const Spacer(),
                    SizedBox(
                      width: 100,
                      child: TextButton(
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all<Color>(Colors.red),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                          ),
                        ),
                        onPressed: () {
                          // Action to perform when the button is pressed
                        },
                        child: const Text(
                          'Save',
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            const Spacer(),
            /* Expanded(
              child: widget.imageFile == null
                  ? Text('No image selected.')
                  : Image.file(File(widget.imageFile.path)),
            ),*/
            Container(
              color: Colors.white.withOpacity(0.4),
              child: Row(
                children: <Widget>[
// First button with icon
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SizedBox(
                      width: 50.0,
                      height: 50.0,
                      child: ElevatedButton(
                        onPressed: () {
                          _onItemButtonsTap(0);
                        },
                        style: ElevatedButton.styleFrom(
                          shape: CircleBorder(),
                          side: BorderSide(
                              color: twoButtonTndex == 0
                                  ? Colors.red
                                  : Colors.transparent),
                          padding: EdgeInsets.all(16.0),
                          backgroundColor: Colors.black,
                        ),
                        child: const Icon(
                          Icons.crop,
                          color: Colors.white,
                          size: 20.0,
                        ),
                      ),
                    ),
                  ),

// Second button with icon
                  SizedBox(
                    width: 50.0,
                    height: 50.0,
                    child: ElevatedButton(
                      onPressed: () {
                        _onItemButtonsTap(1);
                      },
                      style: ElevatedButton.styleFrom(
                        shape: CircleBorder(),
                        side: BorderSide(
                            color: twoButtonTndex == 1
                                ? Colors.red
                                : Colors.transparent),
                        padding: EdgeInsets.all(16.0),
                        backgroundColor: Colors.black,
                      ),
                      child: Image.asset(
                        'assets/images/paint_palette.png',
                        height: 25,
                        width: 25, color: Colors.white,
                        // Adjust to fit your needs
                      ),
                    ),
                  ),
                ],
              ),
            ),
            twoButtonTndex == 0 ? pixelContainer() : palleteContainer(),
          ],
        ),
      ),
    ));
  }

  Widget palleteContainer() {
    return Container(
      color: Colors.white.withOpacity(0.4),
      height: 120,
      padding: EdgeInsets.all(8.0),
      child: Expanded(
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [
            editImageCard("1", "Tile", "16x16 pixels"),
            editImageCard("2", "Tiles", "32x32 pixels"),
            editImageCard("3", "Tiles", "64x64 pixels"),
            editImageCard("4", "Tiles", "32x32 pixels"),
            editImageCard("5", "Tiles", "64x64 pixels"),
            customCard("Add Pallete"),
            // const SizedBox(
            //   height: 20.0,
            // ),
            // editImageCard("", "16x16 pixel"),
          ],
        ),
      ),
    );
  }

  Widget pixelContainer() {
    return Container(
      color: Colors.white.withOpacity(0.4),
      height: 120,
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                editImageCard("1", "Tile", "16x16 pixels"),
                editImageCard("4", "Tiles", "32x32 pixels"),
                editImageCard("16", "Tiles", "64x64 pixels"),
                editImageCard("32", "Tiles", "64x64 pixels"),
                editImageCard("64", "Tiles", "64x64 pixels"),
                editImageCard("128", "Tiles", "64x64 pixels"),
                // editImageCard("", "16x16 pixel"),
              ],
            ),
          ),
          customCard("Custom"),
          const SizedBox(
            height: 20.0,
          ),
        ],
      ),
    );
  }

  Widget customCard(String name) {
    return Container(
      width: 100,
      height: 110,
      child: InkWell(
        onTap: () {
          print("Clicked");
        },
        child: Card(
            elevation: 10.0,
            child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Icon(
                    //   Icons.menu,
                    //   size: 40.0,
                    //   color: Colors.black,
                    // ),
                    Image.asset(
                      'assets/images/setting_lines.png',
                      width: 20,
                      height: 20,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 13.0,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  ],
                ))),
      ),
    );
  }

  Widget editImageCard(String headerText, String tile, String pixel) {
    return Container(
      width: 100,
      height: 100,
      child: Card(
        elevation: 10.0,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                headerText,
                style: const TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                height: 2,
              ),
              Text(
                tile,
                style: const TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 10,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              Text(
                pixel,
                style: const TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
